# InternetofThings_Project
## Links to the User interfaces

[User dashbord](https://thingspeak.com/channels/2496158)

The interface to control the lights is in: Humidity_and_temperature/Light_control.html

## Link to Water tank Thinkspeak (which now has been made public, but was private before)
https://thingspeak.com/channels/2504191
